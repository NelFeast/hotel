<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';

defineOptions({ layout: AppLayout });
</script>
<template>
    <h1>Pridflie</h1>
</template>